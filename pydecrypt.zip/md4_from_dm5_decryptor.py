#!/usr/bin/env python3
# crack_md4_of_md5_nolib.py
# Self-contained: no external Crypto module required.
# Usage: python3 crack_md4_of_md5_nolib.py /path/to/rockyou.txt

import sys
import time
import hashlib
from struct import pack, unpack

TARGET = "49936d23fc511dc678fe5da7d8a84105"

# --- Minimal pure-Python MD4 implementation (public-domain style) ---
# Source idea: small reference MD4 implementations adapted for clarity.
def _F(x, y, z): return ((x & y) | (~x & z)) & 0xFFFFFFFF
def _G(x, y, z): return ((x & y) | (x & z) | (y & z)) & 0xFFFFFFFF
def _H(x, y, z): return (x ^ y ^ z) & 0xFFFFFFFF
def _rol(x, n): return ((x << n) | (x >> (32 - n))) & 0xFFFFFFFF

class MD4:
    def __init__(self):
        # initial state
        self.A = 0x67452301
        self.B = 0xefcdab89
        self.C = 0x98badcfe
        self.D = 0x10325476
        self.count = 0
        self.buffer = b''

    def update(self, data: bytes):
        self.buffer += data
        self.count += len(data)
        while len(self.buffer) >= 64:
            self._compress(self.buffer[:64])
            self.buffer = self.buffer[64:]

    def _compress(self, block):
        X = list(unpack('<16I', block))
        A, B, C, D = self.A, self.B, self.C, self.D

        # Round 1
        s = [3, 7, 11, 19]
        for i in range(16):
            k = i
            r = s[i % 4]
            A = _rol((A + _F(B, C, D) + X[k]) & 0xFFFFFFFF, r)
            A, B, C, D = D, A, B, C

        # Round 2
        s = [3, 5, 9, 13]
        for i in range(16):
            k = (i % 4) * 4 + (i // 4)
            r = s[i % 4]
            A = _rol((A + _G(B, C, D) + X[k] + 0x5A827999) & 0xFFFFFFFF, r)
            A, B, C, D = D, A, B, C

        # Round 3
        s = [3, 9, 11, 15]
        order = [0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15]
        for i in range(16):
            k = order[i]
            r = s[i % 4]
            A = _rol((A + _H(B, C, D) + X[k] + 0x6ed9eba1) & 0xFFFFFFFF, r)
            A, B, C, D = D, A, B, C

        self.A = (self.A + A) & 0xFFFFFFFF
        self.B = (self.B + B) & 0xFFFFFFFF
        self.C = (self.C + C) & 0xFFFFFFFF
        self.D = (self.D + D) & 0xFFFFFFFF

    def digest(self):
        # padding
        padding = b'\x80' + b'\x00' * ((55 - self.count) % 64)
        bit_len = (self.count * 8) & 0xFFFFFFFFFFFFFFFF
        self.update(padding + pack('<Q', bit_len))
        # after padding, buffer should be empty
        return pack('<4I', self.A, self.B, self.C, self.D)

    def hexdigest(self):
        return ''.join(f"{x:02x}" for x in self.digest())

# Helper function: compute md4(hex_md5_string) and return hex
def md4_of_md5_hex_str(password: str) -> str:
    # md5hex = md5(password).hexdigest()
    md5hex = hashlib.md5(password.encode('utf-8')).hexdigest()
    # compute MD4 of the ASCII bytes of md5hex
    m = MD4()
    m.update(md5hex.encode('utf-8'))
    return m.hexdigest()

# --- Main loop: read wordlist and test each password ---
def main():
    if len(sys.argv) < 2:
        print("Usage: python3 crack_md4_of_md5_nolib.py /path/to/rockyou.txt")
        sys.exit(1)
    wordlist = sys.argv[1]
    start = time.time()
    checked = 0
    try:
        with open(wordlist, 'r', errors='ignore') as f:
            for line in f:
                pw = line.rstrip('\r\n')
                checked += 1
                if md4_of_md5_hex_str(pw) == TARGET:
                    print("FOUND:", pw)
                    print("Checked:", checked, "time: {:.2f}s".format(time.time()-start))
                    return
                if checked % 50000 == 0:
                    elapsed = time.time() - start
                    speed = checked / elapsed if elapsed > 0 else 0
                    print(f"Checked {checked} ({speed:.0f} checks/s)")
    except FileNotFoundError:
        print("Wordlist not found:", wordlist)
        sys.exit(2)

    print("Not found in wordlist. Checked:", checked, "time:", f"{time.time()-start:.2f}s")

if __name__ == "__main__":
    main()