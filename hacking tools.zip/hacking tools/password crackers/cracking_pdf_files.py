'''

Before we get started, let’s install the required libraries:
$ pip install pikepdf tqdm
'''

import pikepdf, sys
from tqdm import tqdm

# the target PDF file
pdf_file = sys . argv [ 1 ]

# the word list file
wordlist = sys . argv [ 2 ]

# load password list
passwords = [ line . strip () for line in open ( wordlist )]

# iterate over passwords
for password in tqdm ( passwords , "Decrypting PDF" ):
    try :
        # open PDF file
        with pikepdf.open(pdf_file, password=password) as pdf:
            # Password decrypted successfully, break out of the loop
            print("[+] Password found:", password)
            break
    except pikepdf._qpdf.PasswordError as e:
        # wrong password, just continue in the loop
        continue

'''
continue
First, we load the wordlist file passed from the command lines.
You can also use the RockYou list (as shown in the ZIP cracker
code) or other large wordlists.
Next, we iterate over the list and try to open the file with each
password by passing the password argument to the
pikepdf.open()
method, this will raise
pikepdf._qpdf.PasswordError
if it's an incorrect password. If
that's the case, we will proceed with testing the next password.
We used tqdm
here just to print the progress on how many
words are remaining. Check out my result:
$ python pdf_cracker.py foo-protected.pdf
'''