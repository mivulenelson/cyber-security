import argparse, secrets, random, string

# Setting up the Argument Parser
parser = argparse . ArgumentParser (
    prog = 'Password Generator.' ,
    description = 'Generate any number of passwords with this tool.'
)

# Adding the arguments to the parser
parser . add_argument ( "-n" , "--numbers" , default = 0 , help= "Number of digits in the PW" , type = int )
parser . add_argument ( "-l" , "--lowercase" , default = 0 , help= "Number of lowercase chars in the PW" , type = int )
parser . add_argument ( "-u" , "--uppercase" , default = 0 , help= "Number of uppercase chars in the PW" , type = int )
parser . add_argument ( "-s" , "--special-chars" , default = 0 , help = "Number of special chars in the PW" , type = int )

# add total pw length argument
parser . add_argument ( "-t" , "--total-length" , type = int , help = "The total password length. If passed, it will ignore -n, -l, -u and -s, " "and generate completely random passwords with the specified length" )

'''
The following two arguments are the output file where we store
the passwords and the number of passwords to generate. The
amount
will be an integer, and the output file is a string
(default):
'''

# The amount is a number so we check it to be of type int
parser . add_argument ( "-a" , "--amount" , default = 1 , type =int )
parser . add_argument ( "-o" , "--output-file" )

# Parsing the command line arguments.
args = parser . parse_args ()

'''
We continue with the main part of the program: the password
loop. Here we generate the number of passwords specified by
the user.
We need to define the passwords
list that will hold all the
generated passwords:
'''

# list of passwords
passwords = []

# Looping through the amount of passwords
'''
in the for loop, we first check whether total_length
is passed.
If so, we directly generate the random password using the
length specified
'''
for _ in range ( args .amount):
    if args.total_length:
        # generate random password with the length
        # of total_length based on all available characters
        passwords.append("".join([ secrets . choice ( string .digascii_lettersits + string . punctuation ) for _ in range ( args .total_length)]))
    else:
        password = []

        '''
        We add the possible letters, numbers, and special characters to
        the password list. For each type, we check if it's passed to the
        parser. We get the respective letters from the string module:
        '''

        # how many numbers the password should contain
        for _ in range(args.numbers):
            password.append(secrets.choice(string.digits))

            # how many uppercase characters the password should contain
            for _  in range(args.uppercase):
                password.append(secrets.choice(string.ascii_uppercase))

            # how many lowercase characters the password should contain
            for _ in range(args.lowercase):
                password.append(secrets.choice(string.ascii_lowercase))

            # how many special characters the password should contain
            for _ in range(args.special_chars):
                password.append(secrets.choice(string.punctuation))

            '''
            Then we use the random.shuffle() function to mix up the list. This is done in place:
            '''
        # Shuffle the list with all the possible letters, numbers and symbols.
        random.shuffle(password)

        '''After this, we join the resulting characters with an empty string ""so we have the string version of it         '''

        # Get the letters of the string up to the length argument and then join them.
        password = ''.join(password)

        '''
        Last but not least, we append this password to the passwords list:
        '''
        # append this password to the overall list of password
        passwords.append(password)

        # Store the password to a .txt file
        if args .output_file:
            with open ( args .output_file, 'w' ) as f:
                f.write(' \n '.join(passwords))

                # In all cases, we print out the passwords :
                print(' \n '.join(passwords))

'''
Running the Code
Now let's use the script for generating different password
combinations. First, printing the help:
$ python password_generator.py --help

$ python password_generator.py --total-length 1

let's generate 5 different passwords like that:
$ python password_generator.py --total-length 12 --amount 10

Let's generate a password with five lowercase characters, two uppercase, three digits, and one special character, a total of 11 characters:
$ python password_generator.py -l 5 -u 2 -n 3 -s 1

generating five different passwords based on the same rule:
$ python password_generator.py -l 5 -u 2 -n 3 -s 1 -a 5

That's great! We can also generate random pins of 6 digits:
$ python password_generator.py -n 6 -a 5

Adding four uppercase characters and saving to a file named keys.txt :
$ python password_generator.py -n 6 -u 4 -a 5 --output-file keys.txt

A new keys.txt file will appear in the current working directory that contains these passwords. You can generate as many passwords as possible, such as 5000:
$ python password_generator.py -n 6 -u 4 -a 5000 --output-file keys.txt
'''
