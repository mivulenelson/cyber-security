''''
Since we're using threads, we need to use a lock so only one thread can print at a time
'''

import argparse
import socket
from colorama import init, Fore
from threading import Thread, Lock
from queue import Queue

# some colors
init()
GREEN = Fore.GREEN
RESET = Fore.RESET
GRAY = Fore.LIGHTBLACK_EX

# number of threads, feel free to tune this parameter as you wish
N_THREADS = 200

# thread queue
q = Queue()
print_lock = Lock()

def port_scan(host, port):
    '''
    scan a port on the global variable host
    the function doesn't return anything; we just want to print whether the port is open (feel free to change it, though
    '''
    try:
        s = socket.socket()
        s.connect((host, port))
    except:
        with print_lock:
            print(f"{GRAY}{host :15} : {port :5} is closed {RESET}", end='\r')
    else:
        with print_lock:
            print(f"{GREEN}{host :15} : {port :5} is open {RESET}")
    finally:
        s.close()

def scan_thread():
    global q
    while True:
        # get the port number from the queue, will block until a single item is available in
        # the queue
        worker = q.get()

        # scn that port number
        port_scan(worker)

        # tells the queue that the scanning for that port is done
        q.task_done()

def main(host, ports):
    global q
    for t in range(N_THREADS):
        # for each thread, start it
        t = Thread(target=scan_thread)

        # when we set daemon to true, that thread will end when the main thread ends
        t.daemon = True

        # start the daemon thread
        t.start()

        for worker in ports:
            # for each port, put that port into the queue to start scanning, puts a single item into the queue
            q.put(worker)

            # wait the threads (port scanners) to finish, waits for all daemon threads to finish
            q.join()

if __name__ == "__main__":
    # parse some parameters passed
    parser = argparse.ArgumentParser(description="Fast port scanner")
    parser.add_argument("host", help="Host to scan.")
    parser.add_argument("--ports", "-p", dest="port_range", default="1-65535", help="Port range to scan, default is 1 - 65535 (all ports)")

    args = parser.parse_args()

    start_port, end_port = port_range.split("-")

    start_port, end_port = int(start_port), int(end_port)
    ports = [p for p in range(start_port, end_port)]
    main(host, ports)

# python3 fast_port_scanner.py 192.168.1.1 --ports 1-5000

'''
If you see your scanner is freezing on a single port, that's a sign you need to decrease your number of threads.
If the server you're probing has a high ping, you should reduce N_THREADS to 100, 50, or even lower; try to experiment with this parameter.

An authorized penetration tester can use this tool to see which ports are open,
reveal the presence of potential security devices such as firewalls, and test the network security and the strength of a machine

Most penetration testers often use Nmap to scan ports, as it does not just provide port scanning, but shows services and operating
systems that are running, and much more advanced techniques.

'''

