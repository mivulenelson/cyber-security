''''
IP geolocation for information gathering is a very common task
in information security.

It is used to gather information about the user accessing the system, such as the country, city,
address, and maybe even the latitude and longitude

If you want to follow along, you should go ahead and register
for an account at IPinfo.

It’s worth noting that the free version of the service is limited to 50,000 requests per month, so that’s more than enough for us.

Once registered, you go to the dashboard and grab your access token

$ pip install ipinfo
'''
from os import access

import ipinfo
import sys

from cloudinit.config.cc_disable_ec2_metadata import handle

# get the ip address from the command line
try:
    ip_address = sys.argv[1]
except IndexError:
    ip_address = None

# access token for ipinfor.io
access_token = " "

# create a client object with the access token
handler = ipinfo.getHandler(access_token)

# get the ip info
details = handler.getDetails(ip_address)

# print the ip info
for key, value in details.all.items():
    print(f"{key}: {value}")

#python get_ip_info.py ip_address, runs the code

'''
If you do not pass any IP address, the script will use the IP
address of the computer it is running on

This is useful if you
want to run the script from a remote machine.
'''