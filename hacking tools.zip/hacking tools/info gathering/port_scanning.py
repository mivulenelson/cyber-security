'''
This script will try to connect to a host but on multiple ports. These tools are useful
for hackers and penetration testers, so don't use this tool on a host you don't have permission to test!

pip install colorama
'''

import socket
from colorama import init, Fore

# some colors
init()
GREEN = Fore.GREEN
RESET = Fore.RESET
GRAY = Fore.LIGHTBLACK_EX

def is_port_open(host, port):
    '''
    determine whether host has the port open
    '''

    # creates a new socket
    s = socket.socket()
    try:
        # tries to connect to host suing that port
        s.connect((host, port))

        # make timeout if you want it a little fatser (less accuracy)
        s.settimeout(0.2)
    except:
        # cannot connect, port is closed, return False
        return False
    else:
        # the connection was established, port is open!
        return True

# get the host from the user
host = input("Enter the host:")

# iterate over ports, from 1 to 1024
for port in range(1, 1025):
    if is_port_open(host, port):
        print(f"{GREEN} [+] {host} : {port} is open {RESET}")
    else:
        print(f"{GRAY} [!] {host} : {port} is closed {RESET}", end="\r")