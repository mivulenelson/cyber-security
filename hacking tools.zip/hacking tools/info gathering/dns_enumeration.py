'''
DNS Enumeration is the process of collecting information about
a specific domain’s DNS configuration.

We will be using the dnspython library in Python
pip install dnspython
'''

import dns.resolver

# set the target domain and record type
target_domain = "thepythoncode.com"

# We specify the most common DNS records: A , AAAA , CNAME, MX , NS , SOA , and TXT at (Wikipedia page)
record_types = ["A", "AAAA", "CNAME", "MX", "NS", "SOA", "TXT"]

# create a DNS resolver
resolver = dns.resolver.Resolver()

for record_type in record_types:
    # perform DNS lookup for the target domain and record type
    try:
        answers = resolver.resolve(target_domain, record_type)
    except dns.resolver.NoAnswer:
        continue

    # print the DNS records found
    print(f"DNS records for {target_domain} ({record_type}):")

    for rdata in answers:
        print(rdata)