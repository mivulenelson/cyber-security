""""
Since domain names are stored in a db in a computer, we use python-whois requests
pip install python-whois requests
"""

import whois

def is_registered(domain_name):
    '''
    a function that returns a boolean indicating whether a domain name is registered
    '''
    try:
        w = whois.whois(domain_name)
    except Exception:
        return False
    else:
        return bool(w.domain_name)

if __name__ == "__main__":
    print(is_registered("google.com"))
    