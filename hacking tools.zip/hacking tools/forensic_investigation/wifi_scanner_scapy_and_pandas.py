'''
For this, we need to get Scapy (If you haven’t already) and Pandas installed:
$ pip install pandas scapy

Now the code won't work if you do not enable monitor mode in your network interface; please install aircrack-ng (which comes
pre-installed on Kali Linux) and run the following command:
$ airmon-ng start wlan0
$ iwconfig
$ sudo ifconfig wlan0 down
$ sudo iwconfig wlan0 mode monitor
'''

from scapy . all import *
from threading import Thread
import pandas
import time
import os
import sys

# initialize the networks dataframe that will contain all access points nearby
networks = pandas . DataFrame ( columns =[ "BSSID" , "SSID" , "dBm_Signal" , "Channel" , "Crypto" ])

# set the index BSSID (MAC address of the AP)
networks . set_index ( "BSSID" , inplace = True )

'''
So I've set the BSSID (MAC address of the access point) as the index of each row, as it is unique for every device.
'''

'''
Making the Callback Function
The Scapy’s sniff() function takes the callback function executed whenever a packet is sniffed. Let's implement this function:
'''
def callback ( packet ):
    if packet .haslayer(Dot11Beacon):
        # extract the MAC address of the network
        bssid = packet[Dot11].addr2

        # get the name of it
        ssid = packet[Dot11Elt].inf

        try:
            dbm_signal = packet .dBm_AntSignal
        except:
            dbm_signal = "N/A"

            # extract network stats
            stats = packet[Dot11Beacon].network_stats()

            # get the channel of the AP
            channel = stats.get("channel")

            # get the crypto
            crypto = stats.get("crypto")

            # add the network to our dataframe
            networks.loc[bssid] = (ssid, dbm_signal, channel, crypto)

'''
This callback ensures that the sniffed packet has a beacon layer on it. If this is the case, it will extract the BSSID, SSID (name
of access point), signal, and some stats. Scapy's Dot11Beacon class has the awesome network_stats()
function that extracts valuable information from the network, such as the channel,
rates, and encryption type. Finally, we add this information to the dataframe with the BSSID as the index.

You will encounter some networks that don't have the SSID (ssid equals to "" ), which indicates that it's a hidden network.
In hidden networks, the access point leaves the info field blank to hide the discovery of the network name. You will still find them using this script but without a network name.
Now we need a way to visualize this dataframe. Since we're going to use the sniff() function (which blocks and starts
sniffing in the main thread), we need to use a separate thread to print the content of the networks dataframe, and the below 
code does that:
'''
def print_all ():
    # print all the networks and clear the console every 0.5s
    while True:
        os.system("clear")
        print(networks)
        time.sleep(0.5)

'''
You will notice that not all nearby networks are available if you execute this. That's because we're listening on one WLAN
channel only. We can use the iwconfig command to change the channel. Here is the Python function for it:
'''

def change_channel ():
    ch = 1
    while True:
        # change the channel of the interface
        os.system(f"iwconfig { interface } channel {ch}" )

        # switch channel from 1 to 14 each 0.5s
        ch = ch %14 + 1
        time.sleep(0.5)

'''
For instance, if you want to change to channel 2, the command would be:
$ iwconfig wlan0mon channel 2

Please note that channels 12 and 13 are allowed only in low-power mode as they may interfere with satellite radio waves in
the U.S, while channel 14 is banned and only allowed in Japan.
This will change channels incrementally from 1 to 14 every 0.5 seconds. Let’s write our main code now:
'''

if __name__ == "__main__":
    # interface name, check using iwconfig
    interface = sys.argv[1]

    # start the thread that prints all the networks
    printer = Thread(target=print_all)

    printer.daemon = True
    printer.start()

    # start the channel changer
    channel_changer = Thread(target=change_channel)
    channel_changer.daemon = True
    channel_changer.start()

    # start sniffing
    sniff(prn=callback, iface=interface)

'''
Here’s what we’re doing:
First, we’re reading the interface name from the command-line arguments.
We spawn the thread that will print the and clear the screen every time. Note that we set the of the thread to so this thread
will end whenever the program exits.
We start the thread responsible for changing the Wi-Fi channels. Finally, we run our and pass the it.

Running the Code, Let’s now run the code:
$ python wifi_scanner.py wlan0mon

$ airmon-ng stop wlan0mon
'''