'''
On Linux
On Linux, make sure you have tcpdump
installed on your
machine, Debian/Ubuntu:
$ apt update
$ apt install tcpdump
Fedora/CentOS:
$ yum install tcpdump
After that, you can install Scapy either via pip:
$ pip install scapy
Or using apt/yum:
$ apt install python-scapy

On macOS
You need to have libpcap
$ brew update
$ brew install libpcap
Then, install Scapy via pip:
$ pip install scapy
'''

from scapy . all import  *
import time

def listen_dhcp ():
    # Make sure it is DHCP with the filter options
    sniff(prn=print_packet, filter='udp and (port 67 or port68)' )

'''
In the listen_dhcp()
function, we call the sniff()
pass the print_packet()
function and
function that we'll define as the callback
executed whenever a packet is sniffed and matched by the filter
.
We match UDP packets with port 67 or 68 in their attributes to
filter DHCP
'''

# Let's now define the print_packet() function
def print_packet ( packet ):
    # initialize these variables to None at first
    target_mac, requested_ip, hostname, vendor_id = [ None ] * 4

    # get the MAC address of the requester
    if packet.haslayer(Ether):
        target_mac = packet.getlayer(Ether).src

        # get the DHCP options
        dhcp_options = packet[DHCP].options

        for item in dhcp_options :
            try:
                label, value = item
            except ValueError :
                continue

            if label == 'requested_addr':
                # get the requested IP
                requested_ip = value

            elif label == 'hostname':
                # get the hostname of the device
                hostname = value .decode()

            elif label == 'vendor_class_id' :
                # get the vendor ID
                vendor_id = value .decode()

                if target_mac and vendor_id and hostname and requested_ip :
                    # if all variables are not None, print the device details
                    time_now = time.strftime("[%Y-%m- %d - %H:%M:%S]" )
                    print(f" { time_now } : { target_mac } - { hostname } { vendor_id } requested { requested_ip } " )

'''
First, we extract the MAC address from the src attribute of the Ether packet layer.

Second, if there are DHCP options included in the packet, we
iterate over them and extract the requested_addr requested IP address), hostname
(which is the (the hostname of the requester), and the vendor_class_id (DHCP vendor client ID).
After that, we get the current time and print the details.
Let's start sniffing:
'''

if __name__ == "__main__":
    listen_dhcp()

'''
Running the Script
Before running the script, ensure you're connected to your
network for testing purposes, and then connect with another
device to the network and see the output
'''