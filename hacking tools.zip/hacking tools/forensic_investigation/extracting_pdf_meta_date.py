'''
$ pip install pikepdf
'''

import sys, pikepdf

def get_pdf_metadata ( pdf_file ):
    # read the pdf file
    pdf = pikepdf.Pdf.open(pdf_file)

    # .docinfo attribute contains all the metadata of the PDF document
    return dict(pdf.docinfo)