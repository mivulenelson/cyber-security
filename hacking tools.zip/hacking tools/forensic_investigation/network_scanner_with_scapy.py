from scapy . all import ARP, Ether, srp
target_ip = "192.168.1.1/24"

# IP Address for the destination
# create ARP packet
arp = ARP( pdst = target_ip )

# create the Ether broadcast packet
# ff:ff:ff:ff:ff:ff MAC address indicates broadcasting
ether = Ether( dst = "ff:ff:ff:ff:ff:ff" )

# stack them
packet = ether / arp

'''
If you are unfamiliar with the notation /24 or /16 after the IP
address, it is basically an IP range. For example, 192.168.1.1/24 is a range from 192.168.1.0
to 192.168.1.255 ; the 24 signifies that the first 24 bits of the IP address are dedicated to the
network portion, where the remaining 8 bits (The total bits in an IPv4 address is 32 bits) is for the host portion.
Eight bits for the host portion means that we have host IP
addresses. It is called the CIDR notation. Read this Wikipedia article for more information.
Now we have created these packets, we need to send them using the srp()
function, which sends and receives packets at layer 2 of the TCP/IP model , we set the timeout to 3, so the
script won't get stuck:
'''

# srp() function sends and receives packets at layer 2
result = srp ( packet , timeout = 3 , verbose = 0 )[ 0 ]

'''
The result variable now is a list of pairs that is of the format (sent_packet, received_packet) . Let's iterate over this list:
'''

# a list of clients, we will fill this in the upcoming loop
clients = []

for sent , received in result :
    # for each response, append ip and mac address to 'clients' list
    clients.append({'ip': received.psrc, 'mac': received.hwsrc})

    # print clients
    print("Available devices in the network:")
    print ( "IP" + " " * 18 + "MAC" )

for client in clients:
    print(" {:16} {} " . format ( client [ 'ip' ], client [ 'mac' ]))

'''
Running the Script
Excellent; let’s run the script:
$ python simple_network_scanner.py
'''

