'''
In this section, we will make another function to extract
metadata from video and audio files using the FFmpeg tinytag and
libraries. Let's install them:
$ pip install ffmpeg-python tinytag
'''

def get_media_metadata ( media_file ):
    # uses ffprobe command to extract all possible metadata from media file
    ffmpeg_data = ffmpeg . probe ( media_file )[ "streams" ]
    tt_data = TinyTag . get ( media_file ).as_dict()

    # add both data to a single dict
    return {**tt_data, ** ffmpeg_data}

'''
The ffmpeg.probe() method uses the ffprobe command under
the hood that extracts technical metadata such as the duration, width, channels, and many more

The TinyTag.get() returns an object containing music/video metadata about albums, tracks, composers, etc.

Now, we have three functions for PDF documents, images, and video/audio. Let's make the code that handles which function to
be called based on the passed file's extension
'''

if __name__ == "__main__" :
    file = sys.argv[1]
    if file.endswith(".pdf"):
        pprint(get_pdf_metadata(file))
    elif file.endswith(".jpg"):
        pprint(get_image_metadata(file))
    else:
        pprint(get_media_metadata(file))

'''
First, let’s try it with a PDF document:
$ python metadata.py bert-paper.pd

Let’s now try it with an audio file:
$ python metadata.py Eurielle_Carry_Me.mp3

The following is an execution of one of the images taken by my phone:
$ python metadata.py image.jpg
'''