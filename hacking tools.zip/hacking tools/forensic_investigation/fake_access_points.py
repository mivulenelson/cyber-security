'''
We’ll need to install Scapy and Faker libraries:
$ pip install faker scapy

$ apt-get install aircrack-ng
'''

# Now let’s enable monitor mode using the airmon-ng command:
# root@rockikz:~# airmon-ng start wlan 0

from scapy . all import *

# interface to use to send beacon frames, must be in monitor mode
iface = "wlan0mon"

# generate a random MAC address (built-in in scapy)
sender_mac = RandMAC ()

# SSID (name of access point)
ssid = "Test"

# 802.11 frame
dot11 = Dot11( type = 0 , subtype = 8 , addr1 = "ff:ff:ff:ff:ff:ff" , addr2 = sender_mac , addr3 = sender_mac )

# beacon layer
beacon = Dot11Beacon()

# putting ssid in the frame
essid = Dot11Elt( ID = "SSID" , info = ssid , len = len ( ssid))

# stack all the layers and add a RadioTap
frame = RadioTap()/ dot11 / beacon / essid

# send the frame in layer 2 every 100 milliseconds forever
# using the 'iface' interface
sendp ( frame , inter = 0.1 , iface = iface , loop = 1 )

'''
Forging Multiple Fake Access Points
Now, let's get a little bit fancier and create many fake access points at the same time:
'''

from scapy . all import *
from threading import Thread
from faker import Faker

def send_beacon ( ssid , mac , infinite = True ):
    dot11 = Dot11(type=0, subtype=8, addr1="ff:ff:ff:ff:ff:ff", addr2 = mac , addr3 = mac )

    # type=0:management frame
    # subtype=8:beacon frame
    # addr1:MAC address of the receiver
    # addr2:MAC address of the sender
    # addr3:MAC address of the Access Point (AP)

    # beacon frame
    beacon = Dot11Beacon()

    # we inject the ssid name
    essid = Dot11Elt(ID="SSID", info=ssid, len=len(ssid))

    # stack all the layers and add a RadioTap
    frame = RadioTap() / dot11 / beacon / essid

    # send the frame
    if infinite :
        sendp(frame, inter=0.1, loop=1, iface=iface, verbose = 0 )
    else:
        sendp(frame, iface=iface, verbose=0)

if __name__ == "__main__":
    import argparse

    parser = argparse . ArgumentParser ( description = "Fake Access Point Generator" )
    parser.add_argument("interface", default="wlan0mon", help = "The interface to send beacon frames with, must be in monitor mode" )
    parser.add_argument("-n", "--access-points", type=int, dest = "n_ap" , help = "Number of access points to be generated" )

    args = parser . parse_args ()
    n_ap = args.n_ap

    iface = args.interface

    # generate random SSIDs and MACs
    faker = Faker()

    # generate a list of random SSIDs along with their random MAC
    ssids_macs = [(faker.name(), faker.mac_address()) for i in range ( n_ap ) ]

    for ssid, mac in ssids_macs :
        # spawn a thread for each access point that will send beacon frames
        Thread(target=send_beacon, args=(ssid, mac)).start()

'''
Running the Code
Once you execute the script, the interface will send five beacons each 100 milliseconds (at least in theory). This will result in
appearing of n fake access points.
Let’s run the code and spawn five fake access points:
$ python fake_access_points_forger.py wlan0mon -n 5
'''