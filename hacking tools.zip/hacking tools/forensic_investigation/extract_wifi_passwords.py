'''
As you may already know, Wi-Fi is used to connect to multiple
networks in different places. Your machine surely has a way to
store the Wi-Fi password somewhere, so the next time you
connect, you don't have to re-type it again. This section will
teach you how to make a quick Python script to extract saved
Wi-Fi passwords in either Windows or Unix-based machines.
We won't need any third-party library to be installed, as we'll be
using interacting with the netsh
NetworkManager
command in Windows and the
folder in Unix-based systems such as Linux.
Unlike the changing MAC address code, we will make a single
script that handles the different code for different environments,
so if you're on either platform, it will automatically detect that
and prints the saved passwords accordingly
'''

import  subprocess, os, re, configparser
from collections import namedtuple

'''
On Windows
On Windows, to get all the Wi-Fi names ( ssids ), we use the netsh wlan show profiles
command; the below function uses module to call that command and parses it into the subprocess Python
'''

def get_windows_saved_ssids ():
    """Returns a list of saved SSIDs in a Windows machine using netsh command"""

    # get all saved profiles in the PC
    output = subprocess.check_output("netsh wlan show profiles" ). decode ()

    ssids = []

    profiles = re . findall ( r"All User Profile\s ( . * ) " , output )

    for profile in profiles :
        # for each SSID, remove spaces and colon
        ssid = profile .strip().strip( ":" ).strip()

        # add to the list
        ssids.append(ssid)
        return ssids

'''
We're using regular expressions to find the network profiles.
Next, we can use show profile [ssid] key=clear to get the password of that network:
'''
def get_windows_saved_wifi_passwords ( verbose = 1 ):
    """
    Extracts saved Wi-Fi passwords saved in a Windows machine, this function extracts data using netsh command in Windows
    Args: verbose (int, optional): whether to print saved profiles real-time. Defaults to 1.
    Returns: [list]: list of extracted profiles, a profile has the fields ["ssid", "ciphers", "key"]"""
    ssids = get_windows_saved_ssids()

    Profile = namedtuple ( "Profile" , [ "ssid" , "ciphers" , "key" ])

    profiles = []

    for ssid in ssids:
        ssid_details = subprocess . check_output ( f"""netsh wlanshow profile " { ssid } " key=clear""" ). decode ()

        # get the cipher
        ciphers = re.findall(r"Cipher\s ( . * ) ", ssid_details )

        # clear spaces and colon
        ciphers = "/".join([c.strip().strip(":").strip() for c in ciphers ])

        # get the Wi-Fi password
        key = re.findall(r"Key Content\s ( . * ) ", ssid_details )

        # clear spaces and colon
        try:
            key = key[0].strip().strip(":").strip()
        except IndexError :
            key = "None"
            profile = Profile ( ssid = ssid , ciphers = ciphers , key = key )

            if verbose >= 1 :
                print_windows_profile(profile)
                profiles.append(profile)
                return profiles

'''
First, we call our get_windows_saved_ssids() to get all the
SSIDs we connected to before; we then initialize our namedtuple to include ssid, ciphers, and the key.
We call the show profile [ssid] key=clear for each SSID
extracted, we parse the ciphers and the key (password) using
re.findall() , and then print it with the simpleprint_windows_profile() function:
'''
def print_windows_profile ( profile ):
    """Prints a single profile on Windows"""
    print(f" { profile .ssid :25}{ profile .ciphers :15}{ profile .key :50} " )

    def print_windows_profiles(verbose):
        """Prints all extracted SSIDs along with Key on Windows"""
        print("SSID CIPHER(S) KEY" )
        get_windows_saved_wifi_passwords(verbose)

'''
On Unix-based Systems
These systems are different; in the /etc/NetworkManager/system-connections/
directory, all previously connected networks are located here as INI files. We just have to read these files and
print them in a readable format:
'''

def get_linux_saved_wifi_passwords ( verbose = 1 ):
    """Extracts saved Wi-Fi passwords saved in a Linux machine,
    this function extracts data in the '/etc/NetworkManager/system-
    connections/' directory
    Args: verbose (int, optional): whether to print saved profiles
    real-time. Defaults to 1.
    Returns: [list]: list of extracted profiles, a profile has the
    fields ["ssid", "auth-alg", "key-mgmt", "psk"]"""

    network_connections_path = "/etc/NetworkManager/system-connections/"

    fields = ["ssid", "auth-alg", "key-mgmt", "psk"]

    Profile = namedtuple("Profile", [f.replace("-", "_") for f in fields ])

    profiles = []

    for file in os . listdir ( network_connections_path ):
        data = {k.replace("-", "_"): None for k in fields}

        config = configparser . ConfigParser ()

        config.read(os.path.join(network_connections_path, file))

        for _, section in config . items ():
            for k, v in section . items ():
                if k in fields:
                    data[k.replace("-", "_")] = v
                    profile = Profile(**data )

                    if verbose >= 1 :
                        print_linux_profile(profile)
                        profiles.append(profile)
                        return profiles

'''
As mentioned, we're using the os.listdir() function on that
directory to list all files. We then use configparser to read the
INI file and iterate over the items. If we find the fields we're interested in, we simply include them in our data.
There is other information, but we're sticking to the ssid , auth- alg , key-mgmt , and psk
(password). Next, let's call the function now:
'''
def print_linux_profile ( profile ):
    """Prints a single profile on Linux"""
    print(f" { str ( profile .ssid) :25}{ str ( profile .auth_alg) :5}{str ( profile .key_mgmt) :10}{ str ( profile .psk) :50} " )

    def print_linux_profiles(verbose):
        """Prints all extracted SSIDs along with Key (PSK) on Linux"""
        print("SSID AUTH KEY - MGMT PSK" )
        get_linux_saved_wifi_passwords(verbose)

def print_profiles ( verbose = 1 ):
    if os.name == "nt":
        print_windows_profiles(verbose)
    elif os.name == "posix" :
        print_linux_profiles(verbose)
    else:
        raise NotImplemented("Code only works for either Linux or Windows" )

if __name__ == "__main__" :
    print_profiles()

'''
Running the script:
$ python get_wifi_passwords.py
'''