'''
As you saw, saved passwords on Chrome are quite dangerous to leave them on your computer. Anyone can extract all your saved
passwords on Chrome. How can we protect ourselves from such malicious scripts? One of the easiest ways is to write a script to
access that database and delete all rows from the logins table:
'''

import sqlite3, os

db_path= os . path . join ( os . environ [ "USERPROFILE" ], "AppData" , "Local" , "Google" , "Chrome" , "User Data" , "default" , "Login Data" )
db = sqlite3 . connect ( db_path )

cursor = db . cursor ()

# 'logins' table has the data we need
cursor . execute ( "select origin_url, action_url, username_value, password_value, date_created, date_last_used from logins order by date_created" )

n_logins = len ( cursor . fetchall ())

print (f"Deleting a total of { n_logins } logins...")

cursor . execute ( "delete from logins" )
cursor . connection . commit ()

'''
You’re required to close the Chrome browser and then run the script.
Deleting a total of 204 logins...
Once you open Chrome this time, you'll notice that auto­
complete on login forms is not there anymore. Run the first
script, and you'll see it outputs nothing, so we have successfully
protected ourselves from this!

So as a suggestion, you first run the password extractor to see
the passwords saved on your machine, and then to protect
yourself from this, you run the above code to delete them.
Note that this section only talked about the Login Data
file,
which contains the login credentials. I invite you to explore that
same directory furthermore. For example, there is the History
file with all the visited URLs and keyword searches with a
bunch of other metadata. There are also Cookies , Media
History , Preferences , QuotaManager , Reporting
and NEL ,
Shortcuts , Top Sites , and Web Data .
These are all SQLite databases that you can access. Make sure
you make a copy of the database and then open it, so you
won't close Chrome whenever you want to access it.
In the next section, we will use the Cookies file to extract all the available cookies in your Chrome browser
'''